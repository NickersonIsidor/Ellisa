#include "globals.hpp"

// Initialize our global object
Global g;